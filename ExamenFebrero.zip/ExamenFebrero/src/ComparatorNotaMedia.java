import java.util.Comparator;

public class ComparatorNotaMedia implements Comparator<Alumno>{

	@Override
	public int compare(Alumno a1, Alumno a2) {
		int valor=0;
		
		if(a1.getMedia()>a2.getMedia()) {
			valor=-1;
		}else if(a2.getMedia()>a2.getMedia()) {
			valor=1;
		}else {
			valor=0;
		}
		
		return valor;
		
		
	}

}
