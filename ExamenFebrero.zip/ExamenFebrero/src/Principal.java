import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

public class Principal {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String frase="el gato corre por el jardin";
		tarea5(frase);
	}
	
	public static void tarea1() {
	String ruta="C:\\Users\\Pablo\\OneDrive\\Escritorio\\notasDAM.txt";
	List<Alumno> listaAlumnos= new ArrayList<Alumno>();
	
	cargarAlumnos(ruta,listaAlumnos);
	mostrarAlumnos(listaAlumnos);
	guardarAlumnos(listaAlumnos);
	
	}
	
	public static List<Alumno> cargarAlumnos(String ruta,List<Alumno> listaAlumnos){
		String linea="";
		try {
			BufferedReader reader = new BufferedReader(new FileReader(ruta));
			while((linea=reader.readLine())!=null) {
				String [] partesLinea=linea.split(";");
				String nombre=partesLinea[0];
				double notaP=Double.parseDouble(partesLinea[1]);
				double notaL=Double.parseDouble(partesLinea[2]);
				double notaS=Double.parseDouble(partesLinea[3]);
				
				double notaM=(notaP+notaL+notaS)/3;
				
				Alumno alumno = new Alumno(nombre, notaP, notaL, notaS, notaM);
				
				listaAlumnos.add(alumno);
				
			}
		} catch (Exception e) {
			// TODO: handle exception
		}

		return listaAlumnos;
		
	}
	
	
	public static List<Alumno> mostrarAlumnos(List<Alumno> listaAlumnos){
		Collections.sort(listaAlumnos);
		System.out.println("Nombre "+" Nota Programacion "+" Nota Lenguaje "+" Nota Sistemas");
		for(Alumno al:listaAlumnos) {
			System.out.println(al.toString());
		}
		
		return listaAlumnos;
	}
	
	public static List<Alumno> guardarAlumnos(List<Alumno> listaAlumnos){
		Collections.sort(listaAlumnos, new ComparatorNotaMedia());
		String ruta="C:\\Users\\Pablo\\OneDrive\\Escritorio\\putosMoros.txt";
		try {
			BufferedWriter writer = new BufferedWriter(new FileWriter(ruta));
			for(Alumno al:listaAlumnos) {
				writer.write(al.toString());
				writer.newLine();
			}
			writer.close();
		} catch (Exception e) {
			// TODO: handle exception
		}
		return listaAlumnos;
	}
	
	public static void tarea2() {
		int [] t={3,56,72,47,85,76,56,32,43,76,56,98};
		int clave=56;
		
		buscarTodos(t,clave);
	}
	
	public static int[] buscarTodos(int [] t, int clave) {
		int tamanio=0;
		for(int num:t) {
			if(num==clave) {
				tamanio++;
			}
		}
		
		int [] tablaClaves=new int [tamanio];
		int indice=0;
		
		for(int i=0;i<t.length;i++) {
			if(t[i]==clave) {
				tablaClaves[indice]=i;
				indice++;
			}
		}
		System.out.println(Arrays.toString(tablaClaves));
		return tablaClaves;
	}
	
	
	public static void tarea3() {
		String ruta="C:\\Users\\Pablo\\OneDrive\\Escritorio\\diccionario.txt";
		String linea="";
		Map<String, String> diccionario= new TreeMap<String, String>();
		try {
			BufferedReader reader = new BufferedReader(new FileReader(ruta));
			while((linea=reader.readLine())!=null) {
				String [] partesLinea=linea.split(":");
				String clave=partesLinea[0];
				String definicion=partesLinea[1];
				
				diccionario.put(clave, definicion);
			}
		} catch (Exception e) {
			// TODO: handle exception
		}
		
		Iterator<Map.Entry<String, String>> iterador=diccionario.entrySet().iterator();
		
		while(iterador.hasNext()) {
			Map.Entry<String, String> entry=iterador.next();
			String clave=entry.getKey();
			String definicion=entry.getValue();
			
			System.out.println(clave+":"+definicion);
			
		}
		
		
	}
	
	public static void tarea4() {
		
		List<Integer> listaRandom=new ArrayList<Integer>();
		List<Integer> pares=new ArrayList<Integer>();
		List<Integer> impares=new ArrayList<Integer>();
		for(int i=0;i<=100;i++) {
			int random=(int) (30-10*(Math.random()+10));
			listaRandom.add(random);
		}
		Iterator<Integer> iterador=listaRandom.iterator();
		
		while(iterador.hasNext()) {
			int numero = iterador.next();
			if(numero%2==0) {
				pares.add(numero);
			}else {
				impares.add(numero);
			}
		}
	}
	
	public static void tarea5(String frase) {
		String [] palabras=frase.split(" ");
		frase=frase.toLowerCase();
		for(String palabra:palabras) {
			int longitud=palabra.length();
			if(longitud%2==0) {
				//System.out.print("Es par ");
				char [] letras=palabra.toCharArray();
				for(int i=0;i<letras.length;i++) {
					if(i%2==0) {
						letras[i]=Character.toUpperCase(letras[i]);
					}else {
						letras[i]=Character.toLowerCase(letras[i]);
					}
					
				}
				String palabraFinal=new String(letras);
				 System.out.print(palabraFinal + " ");
				
			}else {
				//System.out.print("Es impar ");
				char [] letras=palabra.toCharArray();
				for(int i=0;i<letras.length;i++) {
					if(i%2==0) {
						letras[i]=Character.toLowerCase(letras[i]);
					}else {
						letras[i]=Character.toUpperCase(letras[i]);
					}
				}
				String palabraFinal=new String(letras);
				 System.out.print(palabraFinal + " ");
			}
			 
		}
	}

}


