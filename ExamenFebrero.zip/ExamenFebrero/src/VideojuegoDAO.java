import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import java.sql.Date;


public class VideojuegoDAO {

	Connection conexion=null;
	
	public VideojuegoDAO() {
		this.conexion=conectar();
	}
	
	public Connection conectar() {
		Connection con=null;
		try {
			String url="jdbc:mysql://localhost:3306/videojuegos";
			String user="root";
			String password="root";
			
			con=DriverManager.getConnection(url, user, password);
			
			System.out.println("Conexion establecida");
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("Error en la conexion");
		}
		return con;
	}
	
	public  void insertar(Videojuego videojuego) {
		try {
			PreparedStatement sentencia=conexion.prepareStatement("INSERT INTO juego (nombre, desarrollador, fechaSalida, precio) VALUES (?,?,?,?)");
			sentencia.setString(1, videojuego.getNombre());
			sentencia.setString(2, videojuego.getDesarrollador());
			sentencia.setDate(3, videojuego.getFechaSalida());
			sentencia.setDouble(4, videojuego.getPrecio());
			
			sentencia.executeUpdate();
			
			System.out.println("Registro introducido correctamente");
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("Error en la inserccion");
		}
	}
	
	public void leer(String nombre) {
		Videojuego v=null;
		try {
			PreparedStatement sentencia=conexion.prepareStatement("SELECT * FROM juego WHERE nombre=?");
			sentencia.setString(1, nombre);
			ResultSet resultados=sentencia.executeQuery();
			resultados.next();
			String nombreR=resultados.getString("nombre");
			String desarrollador=resultados.getString("desarrollador");
			Date fechaSalida=resultados.getDate("fechaSalida");
			double precio=resultados.getDouble("precio");
			
			v=new Videojuego(nombreR, desarrollador, fechaSalida, precio);
			
			System.out.println(v.toString());
		} catch (Exception e) {
			// TODO: handle exception
		}
	}
	
	public List<Videojuego> leerTodos() {
		List<Videojuego> listaJuegos=new ArrayList<Videojuego>();
		try {
			PreparedStatement sentecia=conexion.prepareStatement("SELECT * FROM juego");
			ResultSet resultados=sentecia.executeQuery();
			while(resultados.next()) {
				String nombre=resultados.getString("nombre");
				String desarrollador=resultados.getString("desarrollador");
				Date fecha=resultados.getDate("fechaSalida");
				double precio=resultados.getDouble("precio");
				
				Videojuego v= new Videojuego(nombre, desarrollador, fecha, precio);
				listaJuegos.add(v);
				
			}
			for(Videojuego v:listaJuegos) {
				System.out.println(v.toString());
			}
			
		} catch (Exception e) {
			// TODO: handle exception
		}
		return listaJuegos;
		
	}
}


