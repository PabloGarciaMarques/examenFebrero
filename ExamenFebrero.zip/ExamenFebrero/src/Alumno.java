
public class Alumno implements Comparable<Alumno>{
String nombre;
double notaP;
double notaL;
double notaS;
double media;
public String getNombre() {
	return nombre;
}
public void setNombre(String nombre) {
	this.nombre = nombre;
}
public double getNotaP() {
	return notaP;
}
public void setNotaP(double notaP) {
	this.notaP = notaP;
}
public double getNotaL() {
	return notaL;
}
public void setNotaL(double notaL) {
	this.notaL = notaL;
}
public double getNotaS() {
	return notaS;
}
public void setNotaS(double notaS) {
	this.notaS = notaS;
}
public double getMedia() {
	return media;
}
public void setMedia(double media) {
	this.media = media;
}

public Alumno(String nombre, double notaP, double notaL, double notaS, double media) {
	
	this.nombre = nombre;
	this.notaP = notaP;
	this.notaL = notaL;
	this.notaS = notaS;
	this.media = media;
}
@Override
public int compareTo(Alumno otroAlumno) {
	int comparacion;
	comparacion=Double.compare(otroAlumno.getNotaP(), this.notaP);
	
	if(comparacion==0){
		comparacion=Double.compare(otroAlumno.getNotaL(), this.notaL);
	
	}else if(comparacion==0) {
		comparacion=Double.compare(otroAlumno.getNotaS(), this.notaS);
	}
	return comparacion;
	
}
@Override
public String toString() {
	
	return nombre+"\t"+notaP+"\t"+notaL+"\t"+notaS+"\t"+media ;
}

}
