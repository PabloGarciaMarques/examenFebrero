import java.sql.Date;

public class TestJDBC {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		VideojuegoDAO dao= new VideojuegoDAO();
		
		//Videojuego v= new Videojuego("Metal Gear Solid V:The Panthom Pain", "Capcom", Date.valueOf("2014-07-09"), 55.50);
		
		dao.leerTodos();
	}

}
