import java.sql.Date;

public class Videojuego {
String nombre;
String desarrollador;
Date fechaSalida;
double precio;

public Videojuego(String nombre, String desarrollador, Date fechaSalida, double precio) {

	this.nombre = nombre;
	this.desarrollador = desarrollador;
	this.fechaSalida = fechaSalida;
	this.precio = precio;
}
public String getNombre() {
	return nombre;
}
public void setNombre(String nombre) {
	this.nombre = nombre;
}
public String getDesarrollador() {
	return desarrollador;
}

public void setDesarrollador(String desarrollador) {
	this.desarrollador = desarrollador;
}
public Date getFechaSalida() {
	return fechaSalida;
}
public void setFechaSalida(Date fechaSalida) {
	this.fechaSalida = fechaSalida;
}
public double getPrecio() {
	return precio;
}
public void setPrecio(double precio) {
	this.precio = precio;
}


@Override
public String toString() {
	return "Nombre: "+nombre+"\n"+"Desarrollador: "+desarrollador+"\n"+"Fecha de salida: "+fechaSalida+"\n"+"Precio: "+precio+"\n"+"----------------------------------------";
}
}
