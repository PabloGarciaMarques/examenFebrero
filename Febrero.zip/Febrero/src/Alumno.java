import java.util.function.DoubleToIntFunction;

public class Alumno implements Comparable<Alumno> {
String nombre;
double notaP;
double notaL;
double notaS;
double notaM;
public Alumno(String nombre, double notaP, double notaL, double notaS, double notaM) {
	super();
	this.nombre = nombre;
	this.notaP = notaP;
	this.notaL = notaL;
	this.notaS = notaS;
	this.notaM = notaM;
}
public String getNombre() {
	return nombre;
}
public void setNombre(String nombre) {
	this.nombre = nombre;
}
public double getNotaP() {
	return notaP;
}
public void setNotaP(double notaP) {
	this.notaP = notaP;
}
public double getNotaL() {
	return notaL;
}
public void setNotaL(double notaL) {
	this.notaL = notaL;
}
public double getNotaS() {
	return notaS;
}
public void setNotaS(double notaS) {
	this.notaS = notaS;
}
public double getNotaM() {
	return notaM;
}
public void setNotaM(double notaM) {
	this.notaM = notaM;
}
@Override
public String toString() {
	return nombre+"\t"+notaP+"\t\t"+notaL+"\t\t "+notaS+"\t\t   "+notaM;
}
@Override
public int compareTo(Alumno otroAlumno) {
	return Double.compare(otroAlumno.getNotaM(),this.notaM );
	
}

}
