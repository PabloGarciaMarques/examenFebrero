import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Iterator;
import java.util.Map;
import java.util.Scanner;
import java.util.TreeMap;

public class Principal {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		tarea1();
	}
	public static void tarea1() {
		String ruta="C:\\Users\\EstudianteDAM206\\Desktop\\NotasDAM.txt";
		String rutaDestino="C:\\Users\\EstudianteDAM206\\Desktop\\destino.txt";
		ArrayList<Alumno> listaAlumnos=cargarAlumnos(ruta);
		//mostrarAlumnos(listaAlumnos);
		guardarAlumnos(listaAlumnos, rutaDestino);
	}

	public static ArrayList<Alumno> cargarAlumnos(String ruta) {
		ArrayList<Alumno> listaAlumnos=new ArrayList<Alumno>();
		String linea="";
		try {
			BufferedReader reader = new BufferedReader(new FileReader(ruta)) ;
			while((linea=reader.readLine())!=null) {
				String [] partesLinea=linea.split(";");
				String nombre=partesLinea[0];
				double notaP=Double.parseDouble(partesLinea[1]);
				double notaL=Double.parseDouble(partesLinea[2]);
				double notaS=Double.parseDouble(partesLinea[3]);
				
				double notaM=(notaP+notaL+notaS)/3;
				
				Alumno alumno = new Alumno(nombre, notaP, notaL, notaS, notaM);
				listaAlumnos.add(alumno);
				
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return listaAlumnos;
	}
	
	public static ArrayList<Alumno> mostrarAlumnos(ArrayList<Alumno> listaAlumnos){
		try {
			System.out.println("Nombre "+" Nota de programacion "+" Nota de lenguaje "+" Nota de sistemas "+" Nota media");
			Collections.sort(listaAlumnos, new ComparatorNotaP().thenComparing(new ComparatorNotaL().thenComparing(new ComparatorNotaS())));
			
			Iterator<Alumno> iterator=listaAlumnos.iterator();
			while(iterator.hasNext()) {
				System.out.println(iterator.next());
			}
			
			
		} catch (Exception e) {
			// TODO: handle exception
		}
		return listaAlumnos;
				
	}
	
	public static ArrayList<Alumno> guardarAlumnos(ArrayList<Alumno> listAlumnos, String rutaDestino){
		try {
			BufferedWriter writer= new BufferedWriter(new FileWriter(rutaDestino));
			Collections.sort(listAlumnos);
			Iterator<Alumno> iterator=listAlumnos.iterator();
			while(iterator.hasNext()) {
				Alumno alumno=iterator.next();
				String cadena=alumno.getNombre()+";"+alumno.getNotaP()+";"+alumno.getNotaL()+";"+alumno.getNotaS();
				
				writer.write(cadena);
				writer.newLine();
			}
			System.out.println("Datos guardados correctamente");
			writer.close();
		} catch (Exception e) {
			// TODO: handle exception
		}
		return listAlumnos;
	}
	
	public static void tarea2() {
		int [] t={3,56,72,47,85,76,56,32,43,76,56,98};
		int clave=56;
		
		buscarTodos(t,clave);
	}
	
	public static int[] buscarTodos(int [] t, int clave) {
		int encuentros=0;
		for(int num:t) {
			if(num==clave) {
				encuentros++;
			}
		}
		int [] tablaClaves=new int[encuentros];
		int indice=0;
		
		for(int i=0;i<t.length;i++) {
			if(t[i]==clave) {
				tablaClaves[indice]=i;
				indice++;
			}
		}
		System.out.println(Arrays.toString(tablaClaves));
		return tablaClaves;
	}

	public static void tarea3() {
		String ruta="C:\\Users\\EstudianteDAM206\\Desktop\\Diccionario.txt";
		String linea="";
		Map<String, String> diccionario=new TreeMap<String, String>();
		try {
			BufferedReader reader=new BufferedReader(new FileReader(ruta));
			while((linea=reader.readLine())!=null) {
				String [] parteLinea=linea.split(":");
				String clave=parteLinea[0];
				String definicion=parteLinea[1];
				
				diccionario.put(clave, definicion);
			}
		} catch (Exception e) {
			// TODO: handle exception
		}
		
		Iterator<Map.Entry<String, String>> iterador=diccionario.entrySet().iterator();
		while(iterador.hasNext()) {
			Map.Entry<String, String> entry=iterador.next();
			String clave=entry.getKey();
			String definicion=entry.getValue();
			
			System.out.println(clave+":"+definicion);
		}
	}
	
	public static void tarea4() {
		ArrayList<Integer> listaRandom=new ArrayList<Integer>();
		ArrayList<Integer> listaPares=new ArrayList<Integer>();
		ArrayList<Integer> listaImpares=new ArrayList<Integer>();
	
		for(int i=0;i<=100;i++) {
			int numR=(int)((30-10)*Math.random()+10);
			listaRandom.add(numR);
		}
	
		Iterator<Integer> iterador=listaRandom.iterator();
		while(iterador.hasNext()) {
			int numero=iterador.next();
			if(numero%2==0) {
				listaPares.add(numero);
			}else {
				listaImpares.add(numero);
			}
		}
	}

	public static void tarea5() {
		Scanner sc= new Scanner(System.in);
		System.out.println("Introduce una frase: ");
		String frase=sc.nextLine().trim().toLowerCase();
		
		int longitud=0;
		String [] palabras=frase.split(" ");
		for(String palabra:palabras) {
			longitud=palabra.length();
			if(longitud%2==0) {
				char[] letras=palabra.toCharArray();
				for(int i=0;i<letras.length;i++) {
					if(i%2==0) {
						letras[i]=Character.toUpperCase(letras[i]);
					}else {
						letras[i]=Character.toLowerCase(letras[i]);
					}
				}
				String cadena=new String(letras);
				System.out.print(cadena+" ");
			}else {
				char[] letras=palabra.toCharArray();
				for(int i=0;i<letras.length;i++) {
					if(i%2==0) {
						letras[i]=Character.toLowerCase(letras[i]);
					}else {
						letras[i]=Character.toUpperCase(letras[i]);
					}
				}
				String cadena=new String(letras);
				System.out.print(cadena+" ");
			}
			
		}

	}

}
