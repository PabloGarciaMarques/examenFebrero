import java.sql.Date;

public class TestJDBC {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//VideojuegoDAO dao=new VideojuegoDAO();
		
		//dao.leerTodos();
		
		String cadena="Hola que tal estas";
		String cadenaV="";
		for(int i=cadena.length()-1;i>=0;i--) {
			 cadenaV+=cadena.charAt(i);
		}
		
		System.out.println(cadenaV);
	}

}
