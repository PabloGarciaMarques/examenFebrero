import java.util.Comparator;

public class ComparatorNotaL implements Comparator<Alumno>{
	
		@Override
		public int compare(Alumno a1, Alumno a2) {
			int valor=0;
			if(a1.getNotaL()>a2.getNotaL()) {
				valor = -1;
			}else if(a2.getNotaL()>a1.getNotaL()) {
				valor = 1;
			}else {
				valor=0;
			}
			return valor;
		}

	}


