import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class VideojuegoDAO {

	Connection conexion=null;
	
	public VideojuegoDAO() {
		this.conexion=conectar();
	}
	
	public Connection conectar() {
		Connection con=null;
		try {
			String ruta="jdbc:mysql://localhost:3306/videojuegosdb";
			String user="root";
			String password="rootpablo";
			
			con=DriverManager.getConnection(ruta, user, password);
			System.out.println("Conexion establecida");
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("Error en la conexion");
		}
		return con;
	}
	
	public void insertar(Videojuego videojuego) {
		try {
			PreparedStatement sentencia=conexion.prepareStatement("INSERT INTO juego (Nombre,desarrollador,fechaSalida,precio) VALUES (?,?,?,?)");
			sentencia.setString(1, videojuego.getNombre());
			sentencia.setString(2,videojuego.getDesarrollador());
			sentencia.setDate(3, videojuego.getFechaSalida());
			sentencia.setDouble(4, videojuego.getPrecio());
			
			sentencia.executeUpdate();
			System.out.println("Registro introducido");
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("Error en la inserccion");
		}
	}
	
	public Videojuego leer(String nombre) {
		Videojuego v=null;
		try {
			PreparedStatement sentencia=conexion.prepareStatement("SELECT * FROM juego WHERE nombre=?");
			sentencia.setString(1, nombre);
			ResultSet resultado=sentencia.executeQuery();
			resultado.next();
			String nombreR=resultado.getString("nombre");
			String desarrollador=resultado.getString("desarrollador");
			Date fechaSalida=resultado.getDate("fechaSalida");
			double precio=resultado.getDouble("precio");
			
			v=new Videojuego(nombreR, desarrollador, fechaSalida, precio);
			
			System.out.println(v.toString());
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("No se ha encontrado ningun registro");
		}
		return v;

	}
	
	
	public List<Videojuego> leerTodos() {
		List<Videojuego> listaJuegos=new ArrayList<Videojuego>();
		try {
			PreparedStatement sentencia=conexion.prepareStatement("SELECT * FROM juego");
			ResultSet resultados=sentencia.executeQuery();
			while(resultados.next()) {
				String nombre=resultados.getString("nombre");
				String desarrollador=resultados.getString("desarrollador");
				Date fechaSalida=resultados.getDate("fechaSalida");
				double precio=resultados.getDouble("precio");
				
				Videojuego videojuego=new Videojuego(nombre, desarrollador, fechaSalida, precio);
				
				listaJuegos.add(videojuego);
			}
			for(Videojuego vi:listaJuegos) {
				System.out.println(vi.toString());
			}
		} catch (Exception e) {
			// TODO: handle exception
		}
		return listaJuegos;
	}
	
	
}
