import java.util.Comparator;

public class ComparatorNotaP implements Comparator<Alumno> {

	@Override
	public int compare(Alumno a1, Alumno a2) {
		int valor=0;
		if(a1.getNotaP()>a2.getNotaP()) {
			valor = -1;
		}else if(a2.getNotaP()>a1.getNotaP()) {
			valor = 1;
		}else {
			valor=0;
		}
		return valor;
	}

}
