import java.util.Comparator;
public class ComparatorNotaS implements Comparator<Alumno> {

	@Override
	public int compare(Alumno a1, Alumno a2) {
		int valor=0;
		if(a1.getNotaS()>a2.getNotaS()) {
			valor = -1;
		}else if(a2.getNotaS()>a1.getNotaS()) {
			valor = 1;
		}else {
			valor=0;
		}
		return valor;
	}
	

}
